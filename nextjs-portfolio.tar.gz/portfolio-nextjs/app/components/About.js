'use client'

import Image from 'next/image'

export default function About() {
  const personalInfo = [
    { label: 'Name:', value: 'Vivek Shah' },
    { label: 'Email:', value: 'vivekshah06193@gmail.com' },
    { label: 'Phone:', value: '+91 9924745782' },
    { label: 'Location:', value: 'Ahmedabad, India' },
    { label: 'Education:', value: 'BCA in Computer Science' },
    { label: 'Languages:', value: 'English, Hindi, Gujarati' }
  ]

  return (
    <section className="section" id="about">
      <div className="container">
        <div className="section-header fade-in">
          <p className="section-subtitle">Get To Know More</p>
          <h2 className="section-title">About Me</h2>
          <p className="section-description">
            Crafting seamless, user-centric designs that elevate digital experiences
          </p>
        </div>

        <div className="row g-4 align-items-center">
          <div className="col-lg-5">
            <div className="about-card fade-in">
              <div className="about-image-wrapper">
                <Image 
                  src="https://via.placeholder.com/500x600" 
                  alt="Vivek Shah" 
                  width={500}
                  height={600}
                  className="img-fluid" 
                />
              </div>
            </div>
          </div>

          <div className="col-lg-7">
            <div className="about-card fade-in">
              <h3 className="mb-4">Senior UI/UX Designer</h3>
              <p className="text-muted-custom mb-4">
                I am Vivek Shah, working as a Sr. UI/Web Designer with over 8 years of experience in crafting intuitive, user-centric designs. Currently working at Cygnet Infotech Pvt. Ltd. for over 5 years, I specialize in designing responsive, interactive, and visually compelling interfaces that enhance usability across multiple devices.
              </p>
              <p className="text-muted-custom mb-4">
                My technical expertise includes HTML5, CSS3/SCSS/LESS, JavaScript, jQuery, Bootstrap3+, and UI/UX design tools like Adobe Photoshop, Adobe XD, and Figma. Throughout my career, I have worked closely with developers, ensuring seamless implementation of designs, optimizing web performance, and mentoring junior designers.
              </p>

              <ul className="info-list">
                {personalInfo.map((info, index) => (
                  <li className="info-item" key={index}>
                    <span className="info-label">{info.label}</span>
                    <span className="info-value">{info.value}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

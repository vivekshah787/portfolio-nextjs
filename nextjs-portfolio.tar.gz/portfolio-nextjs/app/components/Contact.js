'use client'

import { useState } from 'react'

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  })

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.id]: e.target.value
    })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    alert('Thank you for your message! I will get back to you soon.')
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    })
  }

  const contactInfo = [
    {
      icon: 'bi-geo-alt',
      title: 'Address',
      details: ['Khokhra, Ahmedabad', 'Gujarat, India']
    },
    {
      icon: 'bi-telephone',
      title: 'Phone',
      details: ['+91 9924745782'],
      link: 'tel:+919924745782'
    },
    {
      icon: 'bi-envelope',
      title: 'Email',
      details: ['vivekshah06193@gmail.com'],
      link: 'mailto:vivekshah06193@gmail.com'
    }
  ]

  return (
    <section className="section" id="contact">
      <div className="container">
        <div className="section-header fade-in">
          <p className="section-subtitle">Get In Touch</p>
          <h2 className="section-title">Contact Me</h2>
          <p className="section-description">
            Let&apos;s discuss your next project and bring your ideas to life
          </p>
        </div>

        <div className="row g-4">
          <div className="col-lg-4">
            <div className="contact-info fade-in">
              {contactInfo.map((info, index) => (
                <div className="contact-item" key={index}>
                  <div className="contact-icon">
                    <i className={`bi ${info.icon}`}></i>
                  </div>
                  <div className="contact-details">
                    <h4>{info.title}</h4>
                    {info.link ? (
                      <p><a href={info.link}>{info.details[0]}</a></p>
                    ) : (
                      info.details.map((detail, idx) => (
                        <p key={idx}>{detail}</p>
                      ))
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="col-lg-8">
            <form className="contact-form fade-in" onSubmit={handleSubmit}>
              <div className="row g-3">
                <div className="col-md-6">
                  <div className="form-group">
                    <label htmlFor="name" className="form-label">Your Name</label>
                    <input
                      type="text"
                      className="form-control"
                      id="name"
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div className="col-md-6">
                  <div className="form-group">
                    <label htmlFor="email" className="form-label">Your Email</label>
                    <input
                      type="email"
                      className="form-control"
                      id="email"
                      placeholder="john@example.com"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div className="col-12">
                  <div className="form-group">
                    <label htmlFor="subject" className="form-label">Subject</label>
                    <input
                      type="text"
                      className="form-control"
                      id="subject"
                      placeholder="How can I help you?"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>

                <div className="col-12">
                  <div className="form-group">
                    <label htmlFor="message" className="form-label">Message</label>
                    <textarea
                      className="form-control"
                      id="message"
                      rows="5"
                      placeholder="Tell me about your project..."
                      value={formData.message}
                      onChange={handleChange}
                      required
                    ></textarea>
                  </div>
                </div>

                <div className="col-12">
                  <button type="submit" className="btn-primary-custom w-100">
                    Send Message
                    <i className="bi bi-send"></i>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
